import { LightningElement } from 'lwc';

/**
 * @slot region1
 * @slot region2
 */
export default class BlankPageLayout extends LightningElement {}