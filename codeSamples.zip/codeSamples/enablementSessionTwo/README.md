# Enablement Session #2 demo
> Customize the Look and Feel of Your LWR Site
## Overview

- How to build a theme layout in LWC
- How to build a page layout in LWC
- How to use branding properties in LWC
- How to use component properties in theme layout LWC
- How to remove SLDS and add a different CSS framework (e.g., Bootstrap)