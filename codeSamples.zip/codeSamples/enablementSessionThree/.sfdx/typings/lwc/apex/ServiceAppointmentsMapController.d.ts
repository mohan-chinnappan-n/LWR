declare module "@salesforce/apex/ServiceAppointmentsMapController.getServiceAppointments" {
  export default function getServiceAppointments(): Promise<any>;
}
