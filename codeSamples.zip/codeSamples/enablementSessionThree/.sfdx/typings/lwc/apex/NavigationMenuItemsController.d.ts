declare module "@salesforce/apex/NavigationMenuItemsController.getNavigationMenuItems" {
  export default function getNavigationMenuItems(param: {menuName: any, publishedState: any}): Promise<any>;
}
