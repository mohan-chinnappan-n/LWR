declare module "@salesforce/apex/GlobalSearchController.searchInObject" {
  export default function searchInObject(param: {searchString: any, objectApiName: any}): Promise<any>;
}
