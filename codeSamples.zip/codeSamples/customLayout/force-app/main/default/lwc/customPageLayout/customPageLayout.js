
import { LightningElement } from 'lwc';

/**
 * @slot header
 * @slot sidebar
 */
export default class CustomThemeLayout extends LightningElement {}
